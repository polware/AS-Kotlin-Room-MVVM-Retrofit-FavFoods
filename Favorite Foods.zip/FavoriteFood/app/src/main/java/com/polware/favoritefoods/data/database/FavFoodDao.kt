package com.polware.favoritefoods.data.database

import androidx.room.*
import com.polware.favoritefoods.data.models.FavoriteFood
import kotlinx.coroutines.flow.Flow

@Dao
interface FavFoodDao {

    @Insert
    suspend fun insertFavFoodDetails(favoriteFood: FavoriteFood)

    // Flow: allow observe data changes on Database
    @Query("SELECT * FROM FAV_FOODS_TABLE ORDER BY ID")
    fun getFoodsList(): Flow<List<FavoriteFood>>

    @Update
    suspend fun updateFavFoodDetails(favoriteFood: FavoriteFood)

    @Query("SELECT * FROM FAV_FOODS_TABLE WHERE favorite_food = 1")
    fun getFavoriteFoods(): Flow<List<FavoriteFood>>

    @Delete
    suspend fun deleteFavFood(favoriteFood: FavoriteFood)

    @Query("SELECT * FROM FAV_FOODS_TABLE WHERE type = :filterType")
    fun getFilteredFoodList(filterType: String): Flow<List<FavoriteFood>>

}