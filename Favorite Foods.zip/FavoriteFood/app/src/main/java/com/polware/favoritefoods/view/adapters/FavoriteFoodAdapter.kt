package com.polware.favoritefoods.view.adapters

import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.PopupMenu
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.polware.favoritefoods.R
import com.polware.favoritefoods.data.Constants
import com.polware.favoritefoods.data.models.FavoriteFood
import com.polware.favoritefoods.databinding.ItemFoodLayoutBinding
import com.polware.favoritefoods.view.activities.AddUpdateFoodActivity
import com.polware.favoritefoods.view.fragments.AllFoodsFragment
import com.polware.favoritefoods.view.fragments.FavoriteFoodsFragment


class FavoriteFoodAdapter(private val fragment: Fragment):
    RecyclerView.Adapter<FavoriteFoodAdapter.MyViewHolder>() {

    private var foods: List<FavoriteFood> = listOf()

    class MyViewHolder(bindingFavFood: ItemFoodLayoutBinding):
        RecyclerView.ViewHolder(bindingFavFood.root) {
        val foodImage = bindingFavFood.ivItemFoodImg
        val foodTitle = bindingFavFood.tvItemFoodTitle
        val btnMoreOptions = bindingFavFood.ibMore
    }

    fun setFoodsList(foodList: List<FavoriteFood>) {
        foods = foodList
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return MyViewHolder(ItemFoodLayoutBinding.inflate(LayoutInflater
            .from(fragment.context), parent, false))
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val food = foods[position]
        Glide.with(fragment)
            .load(food.image)
            .into(holder.foodImage)
        holder.foodTitle.text = food.title

        holder.itemView.setOnClickListener {
            if (fragment is AllFoodsFragment)
                fragment.foodDetails(food)
            else if (fragment is FavoriteFoodsFragment)
                fragment.foodDetails(food)
        }

        if (fragment is AllFoodsFragment) {
            holder.btnMoreOptions.visibility = View.VISIBLE
            holder.btnMoreOptions.setOnClickListener {
                val popupMenu = PopupMenu(fragment.context, holder.btnMoreOptions)
                popupMenu.menuInflater.inflate(R.menu.menu_more_options, popupMenu.menu)
                popupMenu.setOnMenuItemClickListener {
                    if (it.itemId == R.id.action_edit_food) {
                        val intentEdit = Intent(fragment.requireActivity(), AddUpdateFoodActivity::class.java)
                        intentEdit.putExtra(Constants.EXTRA_FOOD_DETAILS, food)
                        fragment.requireActivity().startActivity(intentEdit)
                    }
                    else if (it.itemId == R.id.action_delete_food) {
                        fragment.deleteFood(food)
                    }
                    true
                }
                // Código para mostrar los íconos del menú
                try {
                    val popup = PopupMenu::class.java.getDeclaredField("mPopup")
                    popup.isAccessible = true
                    val menu = popup.get(popupMenu)
                    menu.javaClass.getDeclaredMethod("setForceShowIcon",
                        Boolean::class.java).invoke(menu, true)
                }
                catch (e: Exception) {
                    e.printStackTrace()
                }
                popupMenu.show()
            }
        }
        else if (fragment is FavoriteFoodsFragment)
            holder.btnMoreOptions.visibility = View.GONE

    }

    override fun getItemCount(): Int {
        return foods.size
    }

}