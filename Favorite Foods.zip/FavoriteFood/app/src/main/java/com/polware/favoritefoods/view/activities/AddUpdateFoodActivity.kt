package com.polware.favoritefoods.view.activities

import android.Manifest
import android.app.AlertDialog
import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.text.TextUtils
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.fondesa.kpermissions.*
import com.fondesa.kpermissions.extension.permissionsBuilder
import com.polware.favoritefoods.R
import com.polware.favoritefoods.data.Constants
import com.polware.favoritefoods.data.FavFoodApplication
import com.polware.favoritefoods.data.models.FavoriteFood
import com.polware.favoritefoods.databinding.ActivityAddUpdateFoodBinding
import com.polware.favoritefoods.databinding.DialogDetailsListBinding
import com.polware.favoritefoods.databinding.DialogSelectImageBinding
import com.polware.favoritefoods.view.adapters.FoodDetailsAdapter
import com.polware.favoritefoods.viewmodel.FavFoodViewModel
import com.polware.favoritefoods.viewmodel.FavFoodViewModelFactory
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream
import java.util.*

class AddUpdateFoodActivity : AppCompatActivity(), View.OnClickListener {
    private lateinit var bindingFood: ActivityAddUpdateFoodBinding
    private var activityResultLauncherImageSelected: ActivityResultLauncher<Intent>? = null
    private var activityResultLauncherCameraPhoto: ActivityResultLauncher<Intent>? = null
    private var imagePath: String = ""
    private lateinit var customFoodDetailsDialog: Dialog
    private var favFoodDetails: FavoriteFood? = null

    private val favFoodViewModel: FavFoodViewModel by viewModels {
        FavFoodViewModelFactory((application as FavFoodApplication).repository)
    }

    private val requestPermissionCamera by lazy {
        permissionsBuilder(Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE).build()
    }
    private val requestPermissionStorage by lazy {
        permissionsBuilder(Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE).build()
    }

    companion object {
        private const val IMAGE_FOLDER = "FavFoodsImages"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        bindingFood = ActivityAddUpdateFoodBinding.inflate(layoutInflater)
        setContentView(bindingFood.root)
        getIntentDataForEdit()
        setupActionBar()

        requestPermissionCamera.addListener { result ->
            if (result[0].isGranted() || result.allGranted()) {
                takePhotoFromCamera()
            }
            else if (result[0].isDenied()) {
                Toast.makeText(this, "Camera permission denied", Toast.LENGTH_SHORT).show()
                showRationalDialogForPermissions()
            }
        }
        requestPermissionStorage.addListener{ result ->
            if (result[0].isGranted() || result.allGranted()) {
                choosePhotoFromGallery()
            }
            else if (result.anyPermanentlyDenied()) {
                Toast.makeText(this, "Storage permissions permanently denied", Toast.LENGTH_SHORT).show()
                showRationalDialogForPermissions()
            }
        }

        registerActivityForImageSelected()
        registerActivityForCameraPhoto()
        bindingFood.ivSelectFoodImg.setOnClickListener(this)
        bindingFood.etFoodType.setOnClickListener(this)
        bindingFood.etFoodCategory.setOnClickListener(this)
        bindingFood.etCookingTime.setOnClickListener(this)
        bindingFood.btnSaveFood.setOnClickListener(this)
    }

    private fun setupActionBar() {
        setSupportActionBar(bindingFood.toolbarAddFoodActivity)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        supportActionBar!!.setHomeAsUpIndicator(R.drawable.ic_arrow_back)
        if (favFoodDetails != null && favFoodDetails!!.id != 0) {
            supportActionBar!!.title = "Edit Food"
        }
        else {
            supportActionBar!!.title = "Add Food"
        }

        bindingFood.toolbarAddFoodActivity.setNavigationOnClickListener {
            onBackPressed()
        }
    }

    private fun getIntentDataForEdit() {
        if (intent.hasExtra(Constants.EXTRA_FOOD_DETAILS)) {
            favFoodDetails = intent.getParcelableExtra(Constants.EXTRA_FOOD_DETAILS)
            favFoodDetails.let {
                imagePath = favFoodDetails!!.image
                Glide.with(this).load(imagePath).centerCrop().into(bindingFood.ivFoodImage)
                bindingFood.ivSelectFoodImg.setImageDrawable(ContextCompat
                    .getDrawable(this, R.drawable.ic_vector_edit))
                bindingFood.etFoodTitle.setText(favFoodDetails!!.title)
                bindingFood.etFoodType.setText(favFoodDetails!!.type)
                bindingFood.etFoodCategory.setText(favFoodDetails!!.category)
                bindingFood.etFoodIngredients.setText(favFoodDetails!!.ingredients)
                bindingFood.etCookingTime.setText(favFoodDetails!!.cookingTime)
                bindingFood.etDirectionToCook.setText(favFoodDetails!!.directionToCook)
                bindingFood.btnSaveFood.text = resources.getString(R.string.text_update_button)
            }
        }
    }

    override fun onClick(view: View?) {
        when (view?.id) {
            R.id.iv_select_food_img -> {
                dialogImageSelection()
                return
            }
            R.id.et_food_type -> {
                customItemsListDialog(resources.getString(R.string.title_select_food_type),
                    Constants.foodTypes(), Constants.FOOD_TYPE)
                return
            }
            R.id.et_food_category -> {
                customItemsListDialog(resources.getString(R.string.title_select_food_category),
                    Constants.foodCategories(), Constants.FOOD_CATEGORY)
                return
            }
            R.id.et_cooking_time -> {
                customItemsListDialog(resources.getString(R.string.title_select_food_cooking_time),
                    Constants.foodCookTimes(), Constants.FOOD_COOKING_TIME)
                return
            }
            R.id.btn_save_food -> {
                val title = bindingFood.etFoodTitle.text.toString().trim { it <= ' ' }
                val type = bindingFood.etFoodType.text.toString()
                val category = bindingFood.etFoodCategory.text.toString()
                val ingredients = bindingFood.etFoodIngredients.text.toString()
                val cookingTime = bindingFood.etCookingTime.text.toString()
                val cookingDirection = bindingFood.etDirectionToCook.text.toString().trim { it <= ' ' }
                when {
                    TextUtils.isEmpty(imagePath) -> {
                        Toast.makeText(this, "Please select a food image", Toast.LENGTH_SHORT).show()
                    }
                    TextUtils.isEmpty(title) -> {
                        Toast.makeText(this, "Please enter a food title", Toast.LENGTH_SHORT).show()
                    }
                    TextUtils.isEmpty(type) -> {
                        Toast.makeText(this, "Please select a food type", Toast.LENGTH_SHORT).show()
                    }
                    TextUtils.isEmpty(category) -> {
                        Toast.makeText(this, "Please select a food category", Toast.LENGTH_SHORT).show()
                    }
                    TextUtils.isEmpty(ingredients) -> {
                        Toast.makeText(this, "Please enter the food ingredients", Toast.LENGTH_SHORT).show()
                    }
                    TextUtils.isEmpty(cookingTime) -> {
                        Toast.makeText(this, "Please select food cooking time", Toast.LENGTH_SHORT).show()
                    }
                    TextUtils.isEmpty(cookingDirection) -> {
                        Toast.makeText(this, "Please enter the food cooking instructions", Toast.LENGTH_SHORT).show()
                    }
                    else -> {
                        var foodId = 0
                        var imageSource = Constants.FOOD_IMAGE_SOURCE_LOCAL
                        var favoriteFood = false
                        favFoodDetails?.let {
                            if (it.id != 0) {
                                foodId = it.id
                                imageSource = it.imageSource
                                favoriteFood = it.favoriteFood
                            }
                        }

                        val favFoodModel = FavoriteFood(imagePath,
                            imageSource, title, type, category,
                            ingredients, cookingTime, cookingDirection, favoriteFood, foodId)

                        if (foodId == 0) {
                            favFoodViewModel.insert(favFoodModel)
                            Toast.makeText(this, "Food details successfully saved", Toast.LENGTH_SHORT).show()
                        }
                        else {
                            favFoodViewModel.update(favFoodModel)
                            Toast.makeText(this, "Food details successfully updated", Toast.LENGTH_SHORT).show()
                        }
                        finish()
                    }
                }
                return
            }
        }
    }

    private fun dialogImageSelection() {
        val dialog = Dialog(this)
        val binding: DialogSelectImageBinding = DialogSelectImageBinding.inflate(layoutInflater)
        dialog.setContentView(binding.root)

        binding.tvCamera.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(this,
                    Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                requestPermissionCamera.send()
            }
            else {
                takePhotoFromCamera()
            }
            dialog.dismiss()
        }

        binding.tvGallery.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                requestPermissionStorage.send()
            }
            else {
                choosePhotoFromGallery()
            }
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun takePhotoFromCamera() {
        val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        activityResultLauncherCameraPhoto?.launch(cameraIntent)
    }

    private fun choosePhotoFromGallery(){
        val galleryIntent = Intent(Intent.ACTION_PICK,
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        activityResultLauncherImageSelected?.launch(galleryIntent)
    }

    private fun registerActivityForCameraPhoto() {
        activityResultLauncherCameraPhoto = registerForActivityResult(ActivityResultContracts
            .StartActivityForResult()) {
                result ->
                val resultCode = result.resultCode
                val data = result.data
                if (resultCode == RESULT_OK) {
                    val photo: Bitmap = data!!.extras!!.get("data") as Bitmap
                    imagePath = saveImageToMemory(photo)
                    Log.i("ImagePath: ", imagePath)
                    Glide.with(this).load(photo).centerCrop()
                        .placeholder(R.drawable.add_image_placeholder).into(bindingFood.ivFoodImage)
                    bindingFood.ivSelectFoodImg.setImageDrawable(ContextCompat
                        .getDrawable(this, R.drawable.ic_vector_edit))
                }
                else {
                    Toast.makeText(this, "Failed to capture photo",
                        Toast.LENGTH_SHORT).show()
                }
            }
    }

    private fun registerActivityForImageSelected() {
        activityResultLauncherImageSelected = registerForActivityResult(ActivityResultContracts
            .StartActivityForResult()) {
                result ->
                val resultCode = result.resultCode
                val data = result.data
                if (resultCode == RESULT_OK && data != null) {
                    try {
                        val imageUri = data.data
                        Glide.with(this).load(imageUri).centerCrop()
                            .diskCacheStrategy(DiskCacheStrategy.ALL).listener(object:
                                RequestListener<Drawable> {

                                override fun onLoadFailed(e: GlideException?, model: Any?,
                                    target: Target<Drawable>?, isFirstResource: Boolean): Boolean {
                                    Log.e("LoadFailed: ", e.toString())
                                    return false
                                }

                                override fun onResourceReady(resource: Drawable?, model: Any?,
                                    target: Target<Drawable>?, dataSource: DataSource?,
                                    isFirstResource: Boolean): Boolean {
                                    val bitmap: Bitmap = resource!!.toBitmap()
                                    imagePath = saveImageToMemory(bitmap)
                                    Log.i("ImagePath: ", imagePath)
                                    return false
                                    }
                                })
                            .placeholder(R.drawable.add_image_placeholder)
                            .into(bindingFood.ivFoodImage)
                            bindingFood.ivSelectFoodImg.setImageDrawable(ContextCompat
                                .getDrawable(this, R.drawable.ic_vector_edit))
                    }
                    catch (e: IOException) {
                        e.printStackTrace()
                        Toast.makeText(this, "Error loading image",
                        Toast.LENGTH_SHORT).show()
                    }
                }
            }
    }

    private fun saveImageToMemory(bitmap: Bitmap): String {
        val wrapper = ContextWrapper(applicationContext)
        var file = wrapper.getDir(IMAGE_FOLDER, Context.MODE_PRIVATE)
        file = File(file, "${UUID.randomUUID()}.jpg")
        try {
            val stream: OutputStream = FileOutputStream(file)
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream)
            stream.flush()
            stream.close()
        }
        catch (e: IOException) {
            e.printStackTrace()
        }
        return file.absolutePath
    }

    private fun customItemsListDialog(title: String, itemsList: List<String>, selection: String) {
        customFoodDetailsDialog = Dialog(this)
        val bindingList = DialogDetailsListBinding.inflate(layoutInflater)
        customFoodDetailsDialog.setContentView(bindingList.root)
        bindingList.tvTitleDetails.text = title
        bindingList.rvListDetails.layoutManager = LinearLayoutManager(this)
        // Adapter class is initialized and list is passed in the param
        val adapter = FoodDetailsAdapter(this, null, itemsList, selection)
        // adapter instance is set to the recyclerview to inflate the items
        bindingList.rvListDetails.adapter = adapter
        customFoodDetailsDialog.show()
    }

    fun selectedListItem(item: String, selection: String) {
        when (selection) {
            Constants.FOOD_TYPE -> {
                bindingFood.etFoodType.setText(item)
            }
            Constants.FOOD_CATEGORY -> {
                bindingFood.etFoodCategory.setText(item)
            }
            else -> {
                bindingFood.etCookingTime.setText(item)
            }
        }
        customFoodDetailsDialog.dismiss()
    }

    private fun showRationalDialogForPermissions() {
        AlertDialog.Builder(this).setMessage("You have turned off permission required for" +
                " this feature. It can be enabled under the Applications Settings")
            .setPositiveButton("Go To Settings") {
                _, _ ->
                try {
                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    val uri = Uri.fromParts("package", packageName, null)
                    intent.data = uri
                    startActivity(intent)
                } catch (e: ActivityNotFoundException){
                    e.printStackTrace()
                }
            }
            .setNegativeButton("Cancel") {
                    dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

}