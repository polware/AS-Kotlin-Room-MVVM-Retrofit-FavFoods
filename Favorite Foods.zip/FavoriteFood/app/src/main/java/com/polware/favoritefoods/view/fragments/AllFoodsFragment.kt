package com.polware.favoritefoods.view.fragments

import android.app.AlertDialog
import android.app.Dialog
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.*
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.core.view.MenuHost
import androidx.core.view.MenuProvider
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.polware.favoritefoods.R
import com.polware.favoritefoods.data.Constants
import com.polware.favoritefoods.data.FavFoodApplication
import com.polware.favoritefoods.data.models.FavoriteFood
import com.polware.favoritefoods.databinding.DialogDetailsListBinding
import com.polware.favoritefoods.databinding.FragmentAllFoodsBinding
import com.polware.favoritefoods.view.activities.AddUpdateFoodActivity
import com.polware.favoritefoods.view.activities.MainActivity
import com.polware.favoritefoods.view.adapters.FavoriteFoodAdapter
import com.polware.favoritefoods.view.adapters.FoodDetailsAdapter
import com.polware.favoritefoods.viewmodel.FavFoodViewModel
import com.polware.favoritefoods.viewmodel.FavFoodViewModelFactory

class AllFoodsFragment : Fragment() {
    private var _bindingAF: FragmentAllFoodsBinding? = null
    private val bindingAllFoods get() = _bindingAF!!
    private lateinit var favoriteFoodAdapter: FavoriteFoodAdapter
    private lateinit var customDialog: Dialog

    private val favFoodViewModel: FavFoodViewModel by viewModels {
        FavFoodViewModelFactory((requireActivity().application as FavFoodApplication).repository)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        _bindingAF = FragmentAllFoodsBinding.inflate(inflater, container, false)
        return bindingAllFoods.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupOptionsMenu()
        bindingAllFoods.rvFoodsList.layoutManager = GridLayoutManager(requireActivity(), 2)
        favoriteFoodAdapter = FavoriteFoodAdapter(this)
        bindingAllFoods.rvFoodsList.adapter = favoriteFoodAdapter

        favFoodViewModel.allFoodsList.observe(viewLifecycleOwner) {
            foods ->
            foods.let {
                if (it.isNotEmpty()) {
                    bindingAllFoods.rvFoodsList.visibility = View.VISIBLE
                    bindingAllFoods.tvNoDishesAddedYet.visibility = View.GONE
                    favoriteFoodAdapter.setFoodsList(it)
                }
                else {
                    bindingAllFoods.rvFoodsList.visibility = View.GONE
                    bindingAllFoods.tvNoDishesAddedYet.visibility = View.VISIBLE
                }
            }
        }

    }

    override fun onResume() {
        super.onResume()
        if (requireActivity() is MainActivity)
            (activity as MainActivity).showNavigationView()
    }

    private fun setupOptionsMenu() {
        val menuHost: MenuHost = requireActivity()
        menuHost.addMenuProvider(object : MenuProvider {

            override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
                menu.clear()
                menuInflater.inflate(R.menu.menu_all_foods, menu)
            }

            override fun onMenuItemSelected(menuItem: MenuItem): Boolean {
                return when (menuItem.itemId){
                    R.id.action_filter_foods -> {
                        filterFoodsDialog()
                        true
                    }
                    R.id.action_add_food -> {
                        startActivity(Intent(requireActivity(), AddUpdateFoodActivity::class.java))
                        true
                    }
                    else -> false
                }
            }
        })
    }

    private fun filterFoodsDialog() {
        customDialog = Dialog(requireActivity())
        val bindingDialog = DialogDetailsListBinding.inflate(layoutInflater)
        customDialog.setContentView(bindingDialog.root)
        bindingDialog.tvTitleDetails.text = "Select option to filter:"
        val foodTypes = Constants.foodTypes()
        foodTypes.add(0, Constants.ALL_ITEMS)
        bindingDialog.rvListDetails.layoutManager = LinearLayoutManager(requireActivity())
        val adapter = FoodDetailsAdapter(requireActivity(), this, foodTypes, Constants.FILTER_SELECTION)
        bindingDialog.rvListDetails.adapter = adapter
        customDialog.show()
    }

    fun deleteFood(favoriteFood: FavoriteFood) {
        val builderDialog = AlertDialog.Builder(requireActivity())
        builderDialog.setTitle("Delete Food")
        builderDialog.setMessage(resources.getString(R.string.alert_dialog_delete_msg, favoriteFood.title))
        builderDialog.setIcon(R.drawable.ic_warning_delete)
        builderDialog.setPositiveButton("Yes") {
            dialog, _ ->
            favFoodViewModel.delete(favoriteFood)
            Toast.makeText(requireActivity(), "Food removed from the database", Toast.LENGTH_SHORT).show()
            dialog.dismiss()
        }
        builderDialog.setNegativeButton("No") {
            dialog, _ ->
            dialog.dismiss()
        }
        val alertDialog = builderDialog.create()
        alertDialog.setCancelable(false)
        alertDialog.show()
    }

    fun filterSelection(filterItem: String) {
        customDialog.dismiss()
        Log.i("FilterSelection: ", filterItem)
        if (filterItem == Constants.ALL_ITEMS) {
            favFoodViewModel.allFoodsList.observe(viewLifecycleOwner) {
                foods ->
                foods.let {
                    if (it.isNotEmpty()) {
                        bindingAllFoods.rvFoodsList.visibility = View.VISIBLE
                        bindingAllFoods.tvNoDishesAddedYet.visibility = View.GONE
                        favoriteFoodAdapter.setFoodsList(it)
                    }
                    else {
                        bindingAllFoods.rvFoodsList.visibility = View.GONE
                        bindingAllFoods.tvNoDishesAddedYet.visibility = View.VISIBLE
                    }
                }
            }
        }
        else {
            favFoodViewModel.getFilteredFoodList(filterItem).observe(viewLifecycleOwner) {
                foods ->
                foods.let {
                    if (it.isNotEmpty()) {
                        bindingAllFoods.rvFoodsList.visibility = View.VISIBLE
                        bindingAllFoods.tvNoDishesAddedYet.visibility = View.GONE
                        favoriteFoodAdapter.setFoodsList(it)
                    }
                    else {
                        bindingAllFoods.rvFoodsList.visibility = View.GONE
                        bindingAllFoods.tvNoDishesAddedYet.visibility = View.VISIBLE
                    }
                }
            }

        }
    }

    fun foodDetails(favoriteFood: FavoriteFood) {
        findNavController().navigate(AllFoodsFragmentDirections
            .actionNavigationAllFoodsToFoodDetailsFragment(favoriteFood))
        if (requireActivity() is MainActivity)
            (activity as MainActivity).hideNavigationView()
    }

}