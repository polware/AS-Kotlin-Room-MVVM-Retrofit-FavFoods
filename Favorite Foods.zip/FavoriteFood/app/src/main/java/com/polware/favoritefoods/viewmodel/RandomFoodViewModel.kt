package com.polware.favoritefoods.viewmodel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.polware.favoritefoods.data.api.RetrofitClient
import com.polware.favoritefoods.data.models.RandomFood
import io.reactivex.rxjava3.disposables.CompositeDisposable
import io.reactivex.rxjava3.schedulers.Schedulers
import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers
import io.reactivex.rxjava3.observers.DisposableSingleObserver

class RandomFoodViewModel: ViewModel() {
    private val randomRecipeApiService = RetrofitClient()
    // Disposable: Used to control the lifecycle of an Observable
    private val compositeDisposable = CompositeDisposable()
    val loadRandomFood = MutableLiveData<Boolean>()
    val randomFoodResponse = MutableLiveData<RandomFood.Recipes>()
    val randomFoodLoadingError = MutableLiveData<Boolean>()

    fun getRandomRecipeFromApi() {
        loadRandomFood.value = true
        compositeDisposable.add(randomRecipeApiService.getRandomFood()
            .subscribeOn(Schedulers.newThread())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribeWith(object: DisposableSingleObserver<RandomFood.Recipes>() {

                override fun onSuccess(value: RandomFood.Recipes) {
                    // Update the values with response in the success method
                    loadRandomFood.value = false
                    randomFoodResponse.value = value
                    randomFoodLoadingError.value = false
                }

                override fun onError(e: Throwable) {
                    // Update the values in the response in the error method
                    loadRandomFood.value = false
                    randomFoodLoadingError.value = true
                    Log.e("ErrorApiResponse: ", e.message.toString())
                    e.printStackTrace()
                }
            }))
    }

}