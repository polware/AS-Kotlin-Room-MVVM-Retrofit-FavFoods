package com.polware.favoritefoods.view.adapters

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView
import com.polware.favoritefoods.databinding.ItemDetailsListBinding
import com.polware.favoritefoods.view.activities.AddUpdateFoodActivity
import com.polware.favoritefoods.view.fragments.AllFoodsFragment

class FoodDetailsAdapter(private val activity: Activity, private val fragment: Fragment?,
                         private val listItems: List<String>, private val selection: String):
    RecyclerView.Adapter<FoodDetailsAdapter.MyViewHolder>() {

    class MyViewHolder(bindingAdapter: ItemDetailsListBinding):
        RecyclerView.ViewHolder(bindingAdapter.root) {
        val textViewItemValue = bindingAdapter.tvItemValue
        val imgSelectedItem = bindingAdapter.imageSelectedItem
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return MyViewHolder(ItemDetailsListBinding.inflate(LayoutInflater
            .from(activity), parent, false))
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val item = listItems[position]

        holder.textViewItemValue.text = item

        holder.itemView.setOnClickListener {
            if (activity is AddUpdateFoodActivity) {
                holder.imgSelectedItem.visibility = View.VISIBLE
                Handler(Looper.getMainLooper()).postDelayed({
                    activity.selectedListItem(item, selection)
                }, 350)
            }
            if (fragment is AllFoodsFragment) {
                holder.imgSelectedItem.visibility = View.VISIBLE
                Handler(Looper.getMainLooper()).postDelayed({
                    fragment.filterSelection(item)
                }, 350)
            }
        }

    }

    override fun getItemCount(): Int {
        return listItems.size
    }

}