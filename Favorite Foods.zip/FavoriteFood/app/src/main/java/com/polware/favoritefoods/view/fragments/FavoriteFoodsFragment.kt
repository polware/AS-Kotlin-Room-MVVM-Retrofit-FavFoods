package com.polware.favoritefoods.view.fragments

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.GridLayoutManager
import com.polware.favoritefoods.R
import com.polware.favoritefoods.data.FavFoodApplication
import com.polware.favoritefoods.data.models.FavoriteFood
import com.polware.favoritefoods.databinding.FragmentFavoriteFoodsBinding
import com.polware.favoritefoods.view.activities.MainActivity
import com.polware.favoritefoods.view.adapters.FavoriteFoodAdapter
import com.polware.favoritefoods.viewmodel.FavFoodViewModel
import com.polware.favoritefoods.viewmodel.FavFoodViewModelFactory

class FavoriteFoodsFragment : Fragment() {
    private var _bindingFF: FragmentFavoriteFoodsBinding? = null
    private val bindingFavorites get() = _bindingFF!!

    private val favFoodViewModel: FavFoodViewModel by viewModels {
        FavFoodViewModelFactory(((requireActivity().application) as FavFoodApplication).repository)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                savedInstanceState: Bundle?): View? {
        _bindingFF = FragmentFavoriteFoodsBinding.inflate(inflater, container, false)
        return bindingFavorites.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        favFoodViewModel.favoriteFoods.observe(viewLifecycleOwner) {
            foods ->
            foods.let {
                bindingFavorites.rvFavoriteDishesList.layoutManager =
                    GridLayoutManager(requireActivity(), 2)
                val adapter = FavoriteFoodAdapter(this)
                bindingFavorites.rvFavoriteDishesList.adapter = adapter

                if (it.isNotEmpty()) {
                    bindingFavorites.rvFavoriteDishesList.visibility = View.VISIBLE
                    bindingFavorites.tvNoFavoriteDishesAvailable.visibility = View.GONE
                    adapter.setFoodsList(it)
                }
                else {
                    bindingFavorites.rvFavoriteDishesList.visibility = View.GONE
                    bindingFavorites.tvNoFavoriteDishesAvailable.visibility = View.VISIBLE
                }
            }
        }

    }

    override fun onResume() {
        super.onResume()
        if (requireActivity() is MainActivity)
            (activity as MainActivity).showNavigationView()
    }

    override fun onDestroy() {
        super.onDestroy()
        _bindingFF = null
    }

    fun foodDetails(favoriteFood: FavoriteFood) {
        findNavController().navigate(FavoriteFoodsFragmentDirections
            .actionNavigationFavoriteFoodsToNavigationFoodDetails(favoriteFood))
        if (requireActivity() is MainActivity)
            (activity as MainActivity).hideNavigationView()
    }

}