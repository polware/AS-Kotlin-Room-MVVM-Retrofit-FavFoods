package com.polware.favoritefoods.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.polware.favoritefoods.data.models.FavoriteFood

@Database(entities = [FavoriteFood::class], version = 1)
abstract class FavFoodDatabase: RoomDatabase() {

    abstract fun favFoodDao(): FavFoodDao

    companion object {
        @Volatile
        private var INSTANCE: FavFoodDatabase? = null

        fun getDatabase(context: Context): FavFoodDatabase {
            // If INSTANCE is null, then create the database
            return INSTANCE?: synchronized(this) {
                val instance = Room.databaseBuilder(context.applicationContext,
                    FavFoodDatabase::class.java, "fav_food_database")
                    .fallbackToDestructiveMigration().build()
                INSTANCE = instance
                // Return instance
                instance
            }
        }
    }

}