package com.polware.favoritefoods.data.api

import com.polware.favoritefoods.data.Constants
import com.polware.favoritefoods.data.models.RandomFood
import io.reactivex.rxjava3.core.Single
import retrofit2.Retrofit
import retrofit2.adapter.rxjava3.RxJava3CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory

class RetrofitClient {

    private val apiService = Retrofit.Builder()
        .baseUrl(Constants.BASE_URL)
        // Add converter factory for serialization and deserialization of objects
        .addConverterFactory(GsonConverterFactory.create())
        /**
         * A CallAdapterFactory call adapter which uses RxJava 3 for creating observables.
         * Adding this class to Retrofit allows you to return: Observable, Flowable, Single
         */
        .addCallAdapterFactory(RxJava3CallAdapterFactory.create())
        .build()
        .create(RandomFoodApi::class.java)

    fun getRandomFood(): Single<RandomFood.Recipes> {
        return apiService.getRandomFoodFromApi(
            Constants.API_KEY_VALUE,
            Constants.LIMIT_LICENSE_VALUE,
            Constants.TAGS_VALUE,
            Constants.NUMBER_VALUE
        )
    }

}