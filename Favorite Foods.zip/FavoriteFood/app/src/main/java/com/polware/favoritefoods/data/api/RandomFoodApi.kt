package com.polware.favoritefoods.data.api

import com.polware.favoritefoods.data.Constants
import com.polware.favoritefoods.data.models.RandomFood
import io.reactivex.rxjava3.core.Single
import retrofit2.http.GET
import retrofit2.http.Query

interface RandomFoodApi {

    @GET(Constants.API_ENDPOINT)
    fun getRandomFoodFromApi(
        @Query(Constants.API_KEY) apiKey: String,
        @Query(Constants.LIMIT_LICENSE) limitLicense: Boolean,
        @Query(Constants.TAGS) tags: String,
        @Query(Constants.NUMBER) number: Int): Single<RandomFood.Recipes>
    // Single class implements the Reactive Pattern (RxJava3) for a single value response
    // More info: https://reactivex.io/documentation/single.html

}