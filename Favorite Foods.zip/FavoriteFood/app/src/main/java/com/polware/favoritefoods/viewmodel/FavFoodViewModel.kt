package com.polware.favoritefoods.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.polware.favoritefoods.data.database.FavFoodRepository
import com.polware.favoritefoods.data.models.FavoriteFood
import kotlinx.coroutines.launch

class FavFoodViewModel(private val repository: FavFoodRepository): ViewModel() {

    fun insert(food: FavoriteFood) = viewModelScope.launch {
        repository.insertFavFoodData(food)
    }

    val allFoodsList: LiveData<List<FavoriteFood>> = repository.allFoodsList.asLiveData()

    fun update(food: FavoriteFood) = viewModelScope.launch {
        repository.updateFavFoodData(food)
    }

    val favoriteFoods: LiveData<List<FavoriteFood>> = repository.favoriteFoods.asLiveData()

    fun delete(food: FavoriteFood) = viewModelScope.launch {
        repository.deleteFavFoodData(food)
    }

    fun getFilteredFoodList(value: String): LiveData<List<FavoriteFood>> =
        repository.filteredFoodList(value).asLiveData()

}