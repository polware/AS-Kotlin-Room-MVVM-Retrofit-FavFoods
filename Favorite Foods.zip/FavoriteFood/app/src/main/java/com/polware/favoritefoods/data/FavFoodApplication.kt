package com.polware.favoritefoods.data

import android.app.Application
import com.polware.favoritefoods.data.database.FavFoodDatabase
import com.polware.favoritefoods.data.database.FavFoodRepository

class FavFoodApplication: Application() {

    private val database by lazy {
        FavFoodDatabase.getDatabase(this)
    }

    val repository by lazy {
        FavFoodRepository(database.favFoodDao())
    }

}