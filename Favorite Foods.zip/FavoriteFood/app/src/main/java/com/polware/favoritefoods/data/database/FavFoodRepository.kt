package com.polware.favoritefoods.data.database

import androidx.annotation.WorkerThread
import com.polware.favoritefoods.data.models.FavoriteFood
import kotlinx.coroutines.flow.Flow

/**
 * Design order for RoomDB: Entity, DAO, Database, Repository, ViewModel, VM Factory, Application
 */

class FavFoodRepository(private val favFoodDao: FavFoodDao) {

    // This method should only be called on a worker thread (not use the Main Thread)
    @WorkerThread
    suspend fun insertFavFoodData(favoriteFood: FavoriteFood) {
        favFoodDao.insertFavFoodDetails(favoriteFood)
    }

    // Observed Flow will notify the observer when the data has changed
    val allFoodsList: Flow<List<FavoriteFood>> = favFoodDao.getFoodsList()

    @WorkerThread
    suspend fun updateFavFoodData(favoriteFood: FavoriteFood) {
        favFoodDao.updateFavFoodDetails(favoriteFood)
    }

    val favoriteFoods: Flow<List<FavoriteFood>> = favFoodDao.getFavoriteFoods()

    @WorkerThread
    suspend fun deleteFavFoodData(favoriteFood: FavoriteFood) {
        favFoodDao.deleteFavFood(favoriteFood)
    }

    fun filteredFoodList(value: String): Flow<List<FavoriteFood>> =
        favFoodDao.getFilteredFoodList(value)

}