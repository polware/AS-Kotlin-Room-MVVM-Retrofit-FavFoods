package com.polware.favoritefoods.view.fragments

import android.app.Dialog
import android.os.Build
import android.os.Bundle
import android.text.Html
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.polware.favoritefoods.R
import com.polware.favoritefoods.data.Constants
import com.polware.favoritefoods.data.FavFoodApplication
import com.polware.favoritefoods.data.models.FavoriteFood
import com.polware.favoritefoods.data.models.RandomFood
import com.polware.favoritefoods.databinding.FragmentRandomFoodBinding
import com.polware.favoritefoods.viewmodel.FavFoodViewModel
import com.polware.favoritefoods.viewmodel.FavFoodViewModelFactory
import com.polware.favoritefoods.viewmodel.RandomFoodViewModel

class RandomFoodFragment : Fragment() {
    private var _bindingRF: FragmentRandomFoodBinding? = null
    private val bindingRandom get() = _bindingRF!!
    private lateinit var randomFoodViewModel: RandomFoodViewModel
    private var progressDialog: Dialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        _bindingRF = FragmentRandomFoodBinding.inflate(inflater, container, false)
        return bindingRandom.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        randomFoodViewModel = ViewModelProvider(this)[RandomFoodViewModel::class.java]
        randomFoodViewModel.getRandomRecipeFromApi()
        randomFoodViewModelObserver()

        bindingRandom.srlRandomDish.setOnRefreshListener {
            randomFoodViewModel.getRandomRecipeFromApi()
        }

    }

    override fun onDestroy() {
        super.onDestroy()
        _bindingRF = null
    }

    private fun showProgressDialog() {
        progressDialog = Dialog(requireActivity())
        progressDialog?.let {
            it.setContentView(R.layout.dialog_custom_progress)
            it.show()
        }
    }

    private fun hideProgressDialog() {
        progressDialog?.let {
            it.dismiss()
        }
    }

    private fun randomFoodViewModelObserver() {
        randomFoodViewModel.randomFoodResponse.observe(viewLifecycleOwner) {
            randomFoodResponse ->
            randomFoodResponse.let {
                Log.i("ApiResponse: ", "${randomFoodResponse.recipes[0]}")
                if (bindingRandom.srlRandomDish.isRefreshing) {
                    bindingRandom.srlRandomDish.isRefreshing = false
                }
                setRandomFoodResponse(randomFoodResponse.recipes[0])
            }
        }

        randomFoodViewModel.randomFoodLoadingError.observe(viewLifecycleOwner) {
            error ->
            error.let {
                Log.i("ApiError: ", error.toString())
                if (bindingRandom.srlRandomDish.isRefreshing) {
                    bindingRandom.srlRandomDish.isRefreshing = false
                }
            }
        }

        randomFoodViewModel.loadRandomFood.observe(viewLifecycleOwner) {
            loadRandomFood ->
            loadRandomFood.let {
                Log.i("RandomFoodLoading: ", loadRandomFood.toString())
                // Show progress dialog if the SwipeRefreshLayout is not yet visible
                if (loadRandomFood && !bindingRandom.srlRandomDish.isRefreshing) {
                    showProgressDialog()
                }
                else {
                    hideProgressDialog()
                }
            }
        }
    }

    private fun setRandomFoodResponse(recipe: RandomFood.Recipe) {
        Glide.with(requireActivity())
            .load(recipe.image)
            .centerCrop()
            .into(bindingRandom.ivRandomFoodImage)

        bindingRandom.tvTitle.text = recipe.title
        var dishType = "other"
        if (recipe.dishTypes.isNotEmpty()) {
            dishType = recipe.dishTypes[0]
            bindingRandom.tvType.text = dishType
        }

        // There is not category params present in the response so we will define it as Other
        bindingRandom.tvCategory.text = "Other"
        var ingredients = ""
        for (value in recipe.extendedIngredients) {
            ingredients = if (ingredients.isEmpty()) {
                value.original
            } else {
                ingredients + ", \n" + value.original
            }
        }

        bindingRandom.tvIngredients.text = ingredients
        // The instruction (Cooking direction) text is in the HTML format
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            bindingRandom.tvCookingDirection.text = Html.fromHtml(recipe.instructions,
                Html.FROM_HTML_MODE_COMPACT)
        }
        else {
            @Suppress("DEPRECATION")
            bindingRandom.tvCookingDirection.text = Html.fromHtml(recipe.instructions)
        }

        bindingRandom.tvCookingTime.text =
            resources.getString(R.string.lbl_estimate_cooking_time, recipe.readyInMinutes.toString())

        bindingRandom.ivFavoriteDish.setImageDrawable(ContextCompat.getDrawable(requireActivity(),
            R.drawable.ic_favorite_unselected))
        // Controla que no se agregue 2 veces la misma comida
        var addedToFavorite = false
        bindingRandom.ivFavoriteDish.setOnClickListener {
            if (addedToFavorite) {
                Toast.makeText(requireActivity(),
                    resources.getString(R.string.msg_already_added_to_favorites),
                    Toast.LENGTH_SHORT).show()
            }
            else {
                val randomDishDetails = FavoriteFood(recipe.image, Constants.FOOD_IMAGE_SOURCE_ONLINE,
                    recipe.title, dishType, "Other", ingredients, recipe.readyInMinutes.toString(),
                    recipe.instructions, true)

                val mFavDishViewModel: FavFoodViewModel by viewModels {
                    FavFoodViewModelFactory((requireActivity().application as FavFoodApplication).repository)
                }
                mFavDishViewModel.insert(randomDishDetails)
                addedToFavorite = true
                bindingRandom.ivFavoriteDish.setImageDrawable(ContextCompat
                    .getDrawable(requireActivity(), R.drawable.ic_favorite_selected))
                Toast.makeText(requireActivity(), resources.getString(R.string.msg_added_to_favorites),
                    Toast.LENGTH_SHORT).show()
            }
        }

    }

}