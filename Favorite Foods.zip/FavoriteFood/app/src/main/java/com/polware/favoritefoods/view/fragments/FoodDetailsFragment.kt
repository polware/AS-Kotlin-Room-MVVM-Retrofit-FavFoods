package com.polware.favoritefoods.view.fragments

import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Bundle
import android.text.Html
import android.util.Log
import android.view.*
import androidx.fragment.app.Fragment
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.MenuHost
import androidx.core.view.MenuProvider
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.navArgs
import androidx.palette.graphics.Palette
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.polware.favoritefoods.R
import com.polware.favoritefoods.data.Constants
import com.polware.favoritefoods.data.FavFoodApplication
import com.polware.favoritefoods.data.models.FavoriteFood
import com.polware.favoritefoods.databinding.FragmentFoodDetailsBinding
import com.polware.favoritefoods.viewmodel.FavFoodViewModel
import com.polware.favoritefoods.viewmodel.FavFoodViewModelFactory
import java.io.IOException

class FoodDetailsFragment : Fragment() {
    private var _bindingFD: FragmentFoodDetailsBinding? = null
    private val bindingDetails get() = _bindingFD!!
    private var favFoodDetails: FavoriteFood? = null

    private val favFoodViewModel: FavFoodViewModel by viewModels {
        FavFoodViewModelFactory(((requireActivity().application) as FavFoodApplication).repository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        _bindingFD = FragmentFoodDetailsBinding.inflate(inflater, container, false)
        return bindingDetails.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupOptionsMenu()
        val args: FoodDetailsFragmentArgs by navArgs()
        favFoodDetails = args.foodDetails
        args.let {
            try {
                Glide.with(requireActivity()).load(it.foodDetails.image)
                    .centerCrop().listener(object : RequestListener<Drawable> {

                        override fun onLoadFailed(e: GlideException?, model: Any?,
                            target: Target<Drawable>?, isFirstResource: Boolean ): Boolean {
                            Log.e("ImageLoadFailed: ", e.toString())
                            return false
                        }

                        override fun onResourceReady(resource: Drawable?, model: Any?,
                                        target: Target<Drawable>?, dataSource: DataSource?,
                                        isFirstResource: Boolean): Boolean {
                            // Usamos librería Palette para definir color de fondo según imagen
                            Palette.from(resource!!.toBitmap()).generate() {
                                palette ->
                                val color = palette!!.getLightVibrantColor(ContextCompat.getColor(
                                    context!!, R.color.yellow))
                                bindingDetails.scrollDetailsMain.setBackgroundColor(color)
                            }
                            return false
                        }
                    })
                    .into(bindingDetails.ivFoodImgDetails)
            }
            catch (e: IOException) {
                e.printStackTrace()
            }
            setStateFavoriteFood(args)
            bindingDetails.tvTitle.text = it.foodDetails.title
            bindingDetails.tvType.text = it.foodDetails.type
            bindingDetails.tvCategory.text = it.foodDetails.category
            bindingDetails.tvIngredients.text = it.foodDetails.ingredients

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                bindingDetails.tvCookingDirection.text = Html.fromHtml(it.foodDetails.directionToCook,
                    Html.FROM_HTML_MODE_COMPACT)
            }
            else {
                @Suppress("DEPRECATION")
                bindingDetails.tvCookingDirection.text = Html.fromHtml(it.foodDetails.directionToCook)
            }
            bindingDetails.tvCookingTime.text = resources
                .getString(R.string.lbl_estimate_cooking_time, it.foodDetails.cookingTime)
        }

        bindingDetails.ivFavoriteFood.setOnClickListener {
            args.foodDetails.favoriteFood = !args.foodDetails.favoriteFood
            favFoodViewModel.update(args.foodDetails)
            setStateFavoriteFood(args)
        }
    }

    private fun setupOptionsMenu() {
        val menuHost: MenuHost = requireActivity()
        menuHost.addMenuProvider(object : MenuProvider {

            override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
                menu.clear()
                menuInflater.inflate(R.menu.menu_share_food, menu)
            }

            override fun onMenuItemSelected(menuItem: MenuItem): Boolean {
                return when (menuItem.itemId){
                    R.id.action_share_food -> {
                        val type = "text/plain"
                        val subject = "Checkout this food recipe"
                        var extraText = ""
                        val shareWith = "Share with"
                        favFoodDetails?.let {
                            var image = ""
                            if (it.imageSource == Constants.FOOD_IMAGE_SOURCE_ONLINE) {
                                image = it.image
                            }
                            var cookingInstructions = ""
                            // The instructions (Cooking direction) text is in the HTML format so here convert
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                                cookingInstructions = Html.fromHtml(it.directionToCook,
                                    Html.FROM_HTML_MODE_COMPACT).toString()
                            }
                            else {
                                @Suppress("DEPRECATION")
                                cookingInstructions = Html.fromHtml(it.directionToCook).toString()
                            }

                            extraText = "$image \n\n Title:  ${it.title} \n\n Type: ${it.type}" +
                                    " \n\n Category: ${it.category} \n\n Ingredients: \n ${it.ingredients} " +
                                    "\n\n Instructions To Cook: \n $cookingInstructions \n\n " +
                                    "Time required to cook the dish approx ${it.cookingTime} minutes."
                        }
                        val intentShare = Intent(Intent.ACTION_SEND)
                        intentShare.type = type
                        intentShare.putExtra(Intent.EXTRA_SUBJECT, subject)
                        intentShare.putExtra(Intent.EXTRA_TEXT, extraText)
                        startActivity(Intent.createChooser(intentShare, shareWith))
                        true
                    }
                    else -> false
                }
            }
        })
    }

    private fun setStateFavoriteFood(args: FoodDetailsFragmentArgs) {
        if (args.foodDetails.favoriteFood) {
            bindingDetails.ivFavoriteFood.setImageDrawable(ContextCompat
                .getDrawable(requireActivity(), R.drawable.ic_favorite_selected))
        }
        else {
            bindingDetails.ivFavoriteFood.setImageDrawable(ContextCompat
                .getDrawable(requireActivity(), R.drawable.ic_favorite_unselected))
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        _bindingFD = null
    }

}