package com.polware.favoritefoods.data

object Constants {

    const val FOOD_TYPE = "FoodType"
    const val FOOD_CATEGORY = "FoodCategory"
    const val FOOD_COOKING_TIME = "FoodCookingTime"
    const val FOOD_IMAGE_SOURCE_LOCAL: String = "Local"
    const val FOOD_IMAGE_SOURCE_ONLINE: String = "Online"
    const val EXTRA_FOOD_DETAILS: String = "FoodDetails"
    const val ALL_ITEMS: String = "All Items"
    const val FILTER_SELECTION: String = "FilterSelection"

    // Webpage: https://spoonacular.com/food-api/docs
    const val BASE_URL = "https://api.spoonacular.com/"
    const val API_ENDPOINT: String = "recipes/random"
    // API KEY VALUE from Spoonacular
    const val API_KEY_VALUE: String = "dc37aa23fbe846d2b64a21f1abe9d6ba"
    // PARAMETERS FOR API SERVICE
    const val API_KEY: String = "apiKey"
    const val LIMIT_LICENSE: String = "limitLicense"
    const val TAGS: String = "tags"
    const val NUMBER: String = "number"
    // PARAMS VALUES -> YOU CAN CHANGE AS PER REQUIREMENT FROM HERE
    const val LIMIT_LICENSE_VALUE: Boolean = true
    const val TAGS_VALUE: String = "glutenFree, lunch"
    const val NUMBER_VALUE: Int = 1

    // Notification (WorkerManager)
    const val NOTIFICATION_ID = "FavFood_notification_id"
    const val NOTIFICATION_NAME = "FavFood"
    const val NOTIFICATION_CHANNEL = "FavFood_channel_01"

    fun foodTypes(): ArrayList<String> {
        val typesList = ArrayList<String>()
        typesList.add("Breakfast")
        typesList.add("Lunch")
        typesList.add("Dinner")
        typesList.add("Omelette")
        typesList.add("Soup")
        typesList.add("Snacks")
        typesList.add("Other")
        return typesList
    }

    fun foodCategories(): ArrayList<String> {
        val categoryList = ArrayList<String>()
        categoryList.add("Juices")
        categoryList.add("Drinks")
        categoryList.add("Meats")
        categoryList.add("Tea & coffee")
        categoryList.add("Fast foods")
        categoryList.add("Salads")
        categoryList.add("Desserts")
        categoryList.add("Other")
        return categoryList
    }

    fun foodCookTimes(): ArrayList<String> {
        val timeList = ArrayList<String>()
        timeList.add("10")
        timeList.add("15")
        timeList.add("30")
        timeList.add("45")
        timeList.add("60")
        timeList.add("90")
        timeList.add("120")
        return timeList
    }

}